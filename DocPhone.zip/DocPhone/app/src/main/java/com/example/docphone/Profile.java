package com.example.docphone;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class Profile extends AppCompatActivity {

    public TextView name;
    public Button req_diag;
    public Button emergency;
    //public ImageView profpic;
    private FirebaseAuth mAuth;
    //private DatabaseReference usersRef;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialiseUI();
    }
    public void initialiseUI(){
        name=(TextView)findViewById(R.id.name_text);
        name.setText("Tejas Goel");
        req_diag=(Button)findViewById(R.id.req_diag);
        emergency=(Button)findViewById(R.id.emergency);
    }

    public void diagnosing(View view) {
        Intent intent = new Intent(Profile.this,Diagnosis.class);
        startActivity(intent);
    }

    public void signingout(View view){
        Intent i = new Intent(Profile.this, Login.class);
        startActivity(i);
        Profile.this.finish();
    }
}
