package com.example.docphone;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.DashPathEffect;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Diagnosis extends AppCompatActivity {

    public TextView info;
    public Button setinfo;
    public Button create_model;
    public Button submit;
    public Button cancel;
    public Button add_data;
    public ImageView model;
    static final int PICK_IMAGE_REQUEST = 1;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diagnosis_page);
        initialiseUI();
    }

    public void initialiseUI(){
        info=(TextView)findViewById(R.id.info);
        setinfo=(Button)findViewById(R.id.description);
        create_model=(Button)findViewById(R.id.create_model);
        add_data=(Button)findViewById(R.id.add_data);
        model=(ImageView)findViewById(R.id.model);
        submit=(Button)findViewById(R.id.submit);
        cancel=(Button)findViewById(R.id.cancel);
    }

    public void enteringdetails(View view){
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(Diagnosis.this);
        alertDialog.setTitle("Describe your Problem");

        final EditText input = new EditText(Diagnosis.this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        input.setLayoutParams(lp);
        alertDialog.setView(input);
        alertDialog.setMessage("Recheck information before continuing");

        alertDialog.setPositiveButton("Confirm",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String information = input.getText().toString();
                        info.setText(information);
                        info.setVisibility(View.VISIBLE);
                        setinfo.setVisibility(View.INVISIBLE);
                        create_model.setEnabled(true);
                    }
                });

        alertDialog.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        alertDialog.show();
    }

    public void createmodel(View view){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
        add_data.setEnabled(true);
        submit.setEnabled(true);
        /*Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);*/
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null )
        {
                Bitmap imgbitmap = (Bitmap) data.getExtras().get("data");
                model.setImageBitmap(imgbitmap);
        }

    }

    public void submittoast(View view){
        Toast.makeText(Diagnosis.this, "You have been added to the queue.",
                Toast.LENGTH_SHORT).show();
        Diagnosis.this.finish();
    }

    public void cancelback(View view) {
        Diagnosis.this.finish();
    }
}
