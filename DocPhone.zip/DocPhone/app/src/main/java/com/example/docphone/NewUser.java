package com.example.docphone;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class NewUser extends AppCompatActivity {

    public EditText email;
    public EditText pass;
    public EditText name;
    public Button signup;
    private FirebaseAuth mAuth;
    private DatabaseReference usersRef;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);
        initialiseUI();
    }

    public void initialiseUI(){
        email=(EditText)findViewById(R.id.email);
        pass=(EditText)findViewById(R.id.password);
        name=(EditText)findViewById(R.id.name);
        signup=(Button)findViewById(R.id.signup);
        mAuth= FirebaseAuth.getInstance();
    }

    public void addprofile(View view) {
        mAuth.createUserWithEmailAndPassword(email.getText().toString(), pass.getText().toString())
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            FirebaseUser user = mAuth.getCurrentUser();
                            Toast.makeText(NewUser.this, "User created successfully.",
                                    Toast.LENGTH_LONG).show();

                            usersRef = FirebaseDatabase.getInstance().getReference("users");
                            String id = usersRef.push().getKey();
                            User u = new User(id,name.getText().toString(),email.getText().toString());
                            usersRef.child(id).setValue(u);

                            Intent i = new Intent(NewUser.this,Profile.class);
                            startActivity(i);
                            NewUser.this.finish();
                        } else {
                            // If sign in fails, display a message to the user.
                            Toast.makeText(NewUser.this, "Process failed. Try again.",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                });

    }

    public void opensigninalt(View view) {
        Intent intent = new Intent(NewUser.this,Login.class);
        startActivity(intent);
        NewUser.this.finish();
    }
}
