package com.example.docphone;

public class User {

    String UserID;
    String name;
    String email;

    public User(String UserID, String name, String email){
        this.UserID = UserID;
        this.name = name;
        this.email = email;
    }

    public String getUserID() {
        return UserID;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }



}
